require.config({
    paths : {
        "jquery" : "../js/libs/jquery.min",
        "bootstrap" : "../js/libs/bootstrap.min",
        "moduleHtml":'../js/common',
        "bootstrapValidator":'../js/libs/bootstrapValidator.min'
    }
    ,
    shim: {
        'bootstrap': {
　　　　　　　　deps: ['jquery'],
　　　　　　　　exports: 'bootstrap'
　　　　　　}
        ,
        'bootstrapValidator': {
　　　　　　　　deps: ['jquery','bootstrap'],
　　　　　　　　exports: 'bootstrapValidator'
　　　　　　}
　　　　}
})
define(['jquery','moduleHtml','bootstrap','bootstrapValidator'],function($,template,bootstrapValidator){
    
});
